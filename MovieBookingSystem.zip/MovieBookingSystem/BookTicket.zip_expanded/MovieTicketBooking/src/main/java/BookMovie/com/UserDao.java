package BookMovie.com;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class UserDao {

    // Register a new user
    public void registerUser(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
        }
    }

    // Get a user's bookings (dummy implementation assumes you link user bookings)
    public List<User> getUserBookings(String userName) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from User where name = :userName", User.class)
                    .setParameter("userName", userName)
                    .list();
        }
    }

    // Update user details
    public void updateUser(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(user);
            transaction.commit();
        }
    }

    // Delete a user
    public void deleteUser(String userName) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            User user = session.createQuery("from User where name = :userName", User.class)
                    .setParameter("userName", userName)
                    .uniqueResult();
            if (user != null) session.delete(user);
            transaction.commit();
        }
    }

    // List all users
    public List<User> listAllUsers() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from User", User.class).list();
        }
    }
}
