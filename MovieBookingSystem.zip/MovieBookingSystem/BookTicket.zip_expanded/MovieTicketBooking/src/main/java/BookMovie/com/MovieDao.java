package BookMovie.com;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class MovieDao {

    // Add a new movie
    public void addMovie(Movie movie) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(movie);
            transaction.commit();
        }
    }

    // List all movies
    public List<Movie> listAllMovies() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Movie", Movie.class).list();
        }
    }

    // Get seats available for a movie
    public int getSeatsAvailable(String title) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Movie movie = session.get(Movie.class, title);
            return movie != null ? movie.getSeatsAvailable() : 0;
        }
    }

    // Update seats available after booking or cancellation
    public void updateSeats(String title, int newSeatCount) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            Movie movie = session.get(Movie.class, title);
            if (movie != null) {
                movie.setSeatsAvailable(newSeatCount);
                session.update(movie);
            }
            transaction.commit();
        }
    }

    // Delete a movie
    public void deleteMovie(String title) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            Movie movie = session.get(Movie.class, title);
            if (movie != null) session.delete(movie);
            transaction.commit();
        }
    }
}

