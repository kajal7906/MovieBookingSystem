package BookMovie.com;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class BookingDao {

	// Book a ticket
    public void bookTicket(Booking booking) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(booking);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Cancel a booking and increment movie seats
    public void cancelBooking(int bookingId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            // Find the booking by ID
            Booking booking = session.get(Booking.class, bookingId);
            if (booking != null) {
                // Get the associated movie title
                String movieTitle = booking.getMovieTitle();

                // Find the movie and increment its seat count
                Movie movie = session.get(Movie.class, movieTitle);
                if (movie != null) {
                    movie.setSeatsAvailable(movie.getSeatsAvailable() + 1);
                    session.update(movie);
                }

                // Delete the booking
                session.delete(booking);
                System.out.println("Booking canceled successfully.");
            } else {
                System.out.println("Booking ID not found.");
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // View all bookings
    public List<Booking> viewAllBookings() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Booking", Booking.class).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

