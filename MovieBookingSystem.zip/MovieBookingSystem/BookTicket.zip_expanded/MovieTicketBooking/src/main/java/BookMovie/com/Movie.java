package BookMovie.com;

import javax.persistence.*;

@Entity
@Table(name = "movies")
public class Movie {
    @Id
    private String title;

    @Column(nullable = false)
    private double price;

    @Column(name = "seats_available", nullable = false)
    private int seatsAvailable;

    public Movie() {} // Default constructor

    public Movie(String title, double price, int seatsAvailable) {
        this.title = title;
        this.price = price;
        this.seatsAvailable = seatsAvailable;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSeatsAvailable() {
        return seatsAvailable;
    }

    public void setSeatsAvailable(int seatsAvailable) {
        this.seatsAvailable = seatsAvailable;
    }
}
